import { CheckSquare, Clock, DollarSign, Users, Plus } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { StatsCard } from "@/components/StatsCard";
import { TaskTable, Task } from "@/components/TaskTable";
import { CreateTaskDialog } from "@/components/CreateTaskDialog";
import { Button } from "@/components/ui/button";
import { getAuthHeader } from "@/lib/auth";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { data: tasks, isLoading } = useQuery({
    queryKey: ["/api/tasks"],
    queryFn: async () => {
      const response = await fetch("/api/tasks", {
        headers: getAuthHeader(),
      });
      if (!response.ok) {
        throw new Error("Failed to fetch tasks");
      }
      return response.json() as Promise<Task[]>;
    },
  });

  const totalTasks = tasks?.length || 0;
  const inProgressTasks = tasks?.filter((t) => t.status === "in-progress").length || 0;
  const completedTasks = tasks?.filter((t) => t.status === "completed").length || 0;
  const totalHours = tasks?.reduce((sum, t) => sum + (t.hoursSpent || 0), 0) || 0;
  
  const recentTasks = tasks?.slice(0, 5) || [];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-4xl font-bold" data-testid="text-page-title">
            Dashboard
          </h1>
          <p className="text-muted-foreground mt-1">
            Welcome back! Here's an overview of your projects.
          </p>
        </div>
        <CreateTaskDialog
          trigger={
            <Button data-testid="button-create-task">
              <Plus className="h-4 w-4 mr-2" />
              New Task
            </Button>
          }
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Total Tasks"
          value={totalTasks}
          description={`${inProgressTasks} in progress`}
          icon={CheckSquare}
        />
        <StatsCard
          title="Hours Tracked"
          value={totalHours.toFixed(1)}
          description="This month"
          icon={Clock}
        />
        <StatsCard
          title="Completed"
          value={completedTasks}
          description="Tasks finished"
          icon={DollarSign}
        />
        <StatsCard
          title="Team Members"
          value={1}
          description="Active users"
          icon={Users}
        />
      </div>

      <div>
        <h2 className="text-2xl font-semibold mb-4">Recent Tasks</h2>
        {isLoading ? (
          <div className="border rounded-lg p-4 space-y-3">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        ) : (
          <TaskTable
            tasks={recentTasks}
            onEdit={(task) => console.log("Edit task:", task)}
            onDelete={(id) => console.log("Delete task:", id)}
          />
        )}
      </div>
    </div>
  );
}

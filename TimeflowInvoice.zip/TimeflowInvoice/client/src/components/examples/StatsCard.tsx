import { StatsCard } from "../StatsCard";
import { CheckSquare, Clock, DollarSign, Users } from "lucide-react";

export default function StatsCardExample() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 p-4">
      <StatsCard
        title="Total Tasks"
        value={24}
        description="8 in progress"
        icon={CheckSquare}
        trend={{ value: 12, isPositive: true }}
      />
      <StatsCard
        title="Hours Tracked"
        value="156.5"
        description="This month"
        icon={Clock}
        trend={{ value: 8, isPositive: true }}
      />
      <StatsCard
        title="Revenue"
        value="$12,450"
        description="Pending invoices"
        icon={DollarSign}
        trend={{ value: -3, isPositive: false }}
      />
      <StatsCard
        title="Team Members"
        value={6}
        description="Active users"
        icon={Users}
      />
    </div>
  );
}

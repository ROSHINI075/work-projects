import { TaskTable, Task } from "../TaskTable";

const mockTasks: Task[] = [
  {
    id: "1",
    title: "Design dashboard mockups",
    description: "Create high-fidelity designs for the main dashboard",
    status: "completed",
    priority: "high",
    hoursSpent: 8.5,
    assignee: "Sarah Chen",
  },
  {
    id: "2",
    title: "Implement authentication",
    description: "Set up JWT-based auth with login and registration",
    status: "in-progress",
    priority: "high",
    hoursSpent: 12.0,
    assignee: "Mike Johnson",
  },
  {
    id: "3",
    title: "Write API documentation",
    description: "Document all REST endpoints with examples",
    status: "todo",
    priority: "medium",
    hoursSpent: 0,
    assignee: "John Doe",
  },
  {
    id: "4",
    title: "Setup CI/CD pipeline",
    description: "Configure automated testing and deployment",
    status: "todo",
    priority: "low",
    hoursSpent: 2.5,
    assignee: "Emma Wilson",
  },
];

export default function TaskTableExample() {
  return (
    <div className="p-4">
      <TaskTable
        tasks={mockTasks}
        onEdit={(task) => console.log("Edit task:", task)}
        onDelete={(id) => console.log("Delete task:", id)}
      />
    </div>
  );
}

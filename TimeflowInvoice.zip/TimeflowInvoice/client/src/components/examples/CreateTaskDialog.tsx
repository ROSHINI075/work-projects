import { CreateTaskDialog } from "../CreateTaskDialog";

export default function CreateTaskDialogExample() {
  return (
    <div className="p-4">
      <CreateTaskDialog onSubmit={(data) => console.log("Task submitted:", data)} />
    </div>
  );
}

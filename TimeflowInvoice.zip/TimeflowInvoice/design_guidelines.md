# Design Guidelines: Task Management & Time Tracking Application

## Design Approach
**Selected Approach:** Design System (Tailwind CSS) with inspiration from Linear and Notion
**Rationale:** Utility-focused productivity tool for data teams requires efficiency, clarity, and professional polish. The application is information-dense with forms, tables, and dashboards as core elements.

---

## Core Design Principles
1. **Clarity First:** Every element serves a functional purpose
2. **Density with Breathing Room:** Information-rich but not cramped
3. **Trustworthy & Professional:** Enterprise-grade appearance for financial operations
4. **Efficiency-Driven:** Minimize clicks, maximize clarity

---

## Typography System
**Font Families:** Inter (primary), JetBrains Mono (code/numbers)

**Hierarchy:**
- H1: text-4xl font-bold (Dashboard headings)
- H2: text-2xl font-semibold (Section titles)
- H3: text-xl font-semibold (Card headers)
- Body: text-base (Main content)
- Small: text-sm (Labels, metadata)
- Tiny: text-xs (Timestamps, helper text)

**Weights:** Use font-medium for emphasis, font-semibold for headings, font-normal for body

---

## Layout System
**Spacing Primitives:** Tailwind units of 2, 4, 6, 8, 12, 16
- Micro spacing: gap-2, p-2
- Component spacing: p-4, gap-4, mb-6
- Section spacing: p-8, gap-8, my-12
- Page margins: p-6 md:p-8

**Grid System:**
- Dashboard: Sidebar (w-64) + Main content (flex-1)
- Forms: Single column, max-w-md centered
- Tables: Full-width with horizontal scroll on mobile
- Cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3

---

## Component Library

### Authentication Pages
- Centered card (max-w-md) on clean background
- Logo/brand at top
- Form fields with clear labels above inputs
- Primary CTA button (full width)
- Secondary links below (text-sm)
- Subtle border around card

### Dashboard Layout
- **Sidebar (Fixed):** Navigation links with icons, user profile at bottom, subtle border-right
- **Header Bar:** Page title (text-2xl), breadcrumbs, action buttons right-aligned
- **Content Area:** Cards with rounded corners (rounded-lg), subtle shadows (shadow-sm)

### Forms
- Labels: font-medium text-sm, mb-1
- Inputs: border with rounded-md, p-3, focus ring
- Validation errors: text-sm text-red-600, mt-1
- Submit button: full width on mobile, auto width on desktop
- Field grouping: space-y-4

### Tables
- Header row: font-semibold, border-b-2
- Rows: hover state, border-b
- Actions column: right-aligned icons/buttons
- Pagination: bottom-center
- Empty state: centered message with icon

### Cards
- Border with rounded-lg
- Padding: p-6
- Header with title + action button
- Content area with space-y-4
- Footer with metadata (text-sm)

### Buttons
- Primary: solid fill, font-medium, px-4 py-2, rounded-md
- Secondary: border, transparent background
- Ghost: no border, hover background
- Icon buttons: square (p-2), rounded

### Navigation
- Top nav: Horizontal links with subtle hover
- Sidebar: Vertical list, active state with background + border-left accent
- Breadcrumbs: text-sm with separators

---

## Dashboard Sections

### Main Dashboard (Post-Login)
1. **Stats Overview:** 3-4 metric cards (grid-cols-1 md:grid-cols-4)
2. **Recent Tasks Table:** Full-width, 5-10 rows with pagination
3. **Quick Actions:** Floating action button or prominent CTA
4. **Time Tracking Widget:** Current timer + recent entries

### Task Management Page
- **List View:** Filterable table with search bar
- **Create Modal:** Slide-over panel from right
- **Detail View:** Split layout (details left, actions right)

### Invoice Generation Page
- **Form Section:** Project selection, date range picker, hourly rates
- **Preview Panel:** Live invoice preview
- **Export Options:** PDF/Email buttons

### Profile Page
- **Avatar Section:** Large circular avatar with upload button
- **Info Fields:** Two-column form (md:grid-cols-2)
- **Save Button:** Bottom-right, sticky on scroll

---

## Interactions & States
- **Loading:** Skeleton loaders for tables/cards, spinner for buttons
- **Success:** Green toast notification (top-right)
- **Error:** Red inline messages + toast
- **Hover:** Subtle background change (bg-gray-50)
- **Focus:** Ring with offset
- **Disabled:** Reduced opacity (opacity-50), cursor-not-allowed

---

## Responsive Behavior
- **Mobile (<768px):** Stack all columns, full-width buttons, hamburger menu
- **Tablet (768-1024px):** 2-column grids, collapsed sidebar
- **Desktop (>1024px):** Full layouts, expanded sidebar

---

## Images
No hero images required (utility application). Use:
- **Empty States:** Simple illustrations for no data scenarios
- **Avatars:** User profile pictures (circular, 40x40 to 128x128)
- **Icons:** Heroicons for all UI icons (outline for nav, solid for emphasis)

---

## Accessibility
- All form inputs have associated labels
- Focus states clearly visible
- Error messages programmatically linked to inputs
- Keyboard navigation throughout
- ARIA labels on icon-only buttons
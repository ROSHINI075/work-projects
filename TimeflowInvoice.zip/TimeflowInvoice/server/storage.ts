import { users, tasks, type User, type InsertUser, type UpdateUser, type Task, type InsertTask, type UpdateTask, type TaskWithAssignee } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: UpdateUser): Promise<User | undefined>;
  
  // Task methods
  getTask(id: string): Promise<TaskWithAssignee | undefined>;
  getTasks(userId?: string): Promise<TaskWithAssignee[]>;
  createTask(task: InsertTask & { createdById: string }): Promise<Task>;
  updateTask(id: string, task: UpdateTask): Promise<Task | undefined>;
  deleteTask(id: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: string, updateUser: UpdateUser): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updateUser)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getTask(id: string): Promise<TaskWithAssignee | undefined> {
    const [task] = await db
      .select()
      .from(tasks)
      .leftJoin(users, eq(tasks.assigneeId, users.id))
      .where(eq(tasks.id, id));
    
    if (!task || !task.users) {
      return undefined;
    }

    return {
      ...task.tasks,
      assignee: task.users,
    };
  }

  async getTasks(userId?: string): Promise<TaskWithAssignee[]> {
    const query = db
      .select()
      .from(tasks)
      .leftJoin(users, eq(tasks.assigneeId, users.id))
      .orderBy(desc(tasks.createdAt));

    const results = userId 
      ? await query.where(eq(tasks.createdById, userId))
      : await query;

    return results.map((r) => ({
      ...r.tasks,
      assignee: r.users || {
        id: "unknown",
        username: "Unassigned",
        email: "",
        password: "",
        fullName: null,
        role: null,
        hourlyRate: null,
        createdAt: new Date(),
      },
    }));
  }

  async createTask(insertTask: InsertTask & { createdById: string }): Promise<Task> {
    const [task] = await db
      .insert(tasks)
      .values(insertTask)
      .returning();
    return task;
  }

  async updateTask(id: string, updateTask: UpdateTask): Promise<Task | undefined> {
    const [task] = await db
      .update(tasks)
      .set({ ...updateTask, updatedAt: new Date() })
      .where(eq(tasks.id, id))
      .returning();
    return task || undefined;
  }

  async deleteTask(id: string): Promise<boolean> {
    const result = await db.delete(tasks).where(eq(tasks.id, id));
    return result.rowCount !== null && result.rowCount > 0;
  }
}

export const storage = new DatabaseStorage();
